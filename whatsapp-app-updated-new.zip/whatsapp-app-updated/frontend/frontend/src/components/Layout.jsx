import Navbar from './Navbar'

export default function Layout({ children }) {
  return (
    <div className="flex h-screen bg-gray-100">
      <Navbar />
      <main className="flex-1 overflow-y-auto p-6">
        {children}
      </main>
    </div>
  )
}
