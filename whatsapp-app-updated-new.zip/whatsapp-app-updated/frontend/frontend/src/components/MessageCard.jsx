export default function MessageCard({ message }) {
  return (
    <div className={`p-4 rounded-lg shadow ${message.direction === 'incoming' ? 'bg-white' : 'bg-primary-light text-white'}`}>
      <div className="flex justify-between items-start mb-2">
        <span className="font-semibold">{message.contact_name || message.phone_number || 'Unknown'}</span>
        <span className="text-xs text-gray-500">
  {new Date(message.created_at).toLocaleString()}
</span>
      </div>
      <p className="mb-2">{message.message}</p>
      <div className="flex justify-between items-center">
        <span className="text-xs px-2 py-1 bg-gray-200 rounded-full">{message.device_code}</span>
        <span className="text-xs">{message.status || ''}</span>
      </div>
    </div>
  );
}