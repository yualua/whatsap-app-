import { Link } from 'react-router-dom'

export default function Navbar() {
  return (
    <nav className="w-64 bg-primary-dark text-white p-4">
      <h1 className="text-2xl font-bold mb-8">WhatsApp MD</h1>
      <ul className="space-y-2">
        <li>
          <Link to="/" className="block py-2 px-4 rounded hover:bg-primary hover:text-white">
            Dashboard
          </Link>
        </li>
        <li>
          <Link to="/send" className="block py-2 px-4 rounded hover:bg-primary hover:text-white">
            Kirim Pesan
          </Link>
        </li>
        <li>
          <Link to="/contacts" className="block py-2 px-4 rounded hover:bg-primary hover:text-white">
            Kontak
          </Link>
        </li>
        <li>
          <Link to="/history" className="block py-2 px-4 rounded hover:bg-primary hover:text-white">
            Riwayat Chat
          </Link>
        </li>
      </ul>
    </nav>
  )
}
