import { useEffect, useState } from 'react';
import axios from 'axios';
import MessageCard from '../components/MessageCard';

const Dashboard = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const socket = new WebSocket('ws://37.44.244.95:3003');

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      console.log("📩 Pesan masuk dari WebSocket:", data);

      setMessages(prevMessages => [
        {
          id: Date.now(), // ID sementara
          contact_id: null,
          device_code: data.device,
          message: data.message,
          direction: "incoming",
          created_at: new Date().toISOString(),
          phone_number: data.sender
        },
        ...prevMessages
      ]);
    };

    socket.onopen = () => {
      console.log("✅ WebSocket Connected");
    };

    socket.onerror = (error) => {
      console.error("❌ WebSocket Error:", error);
    };

    return () => {
      socket.close();
    };
  }, []);

  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const response = await axios.get('http://37.44.244.95:3002/api/whatsapp/messages/recent');
        setMessages(response.data);
      } catch (error) {
        console.error('Error fetching messages:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMessages();
  }, []);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {messages.map((message) => (
            <MessageCard key={message.id} message={message} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;