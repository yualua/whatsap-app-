import { useEffect, useState } from 'react';
import axios from 'axios';

export default function ChatHistory({ selectedContactId }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!selectedContactId) return;

    const fetchMessages = async () => {
      setLoading(true);
      try {
        const res = await axios.get(`http://37.44.244.95:3002/api/whatsapp/messages/history/${selectedContactId}`);
        setMessages(res.data);
      } catch (err) {
        console.error('Gagal mengambil pesan:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchMessages();
  }, [selectedContactId]);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Riwayat Chat</h1>
      {loading ? (
        <p>Memuat...</p>
      ) : messages.length > 0 ? (
        <ul className="space-y-2">
          {messages.map((msg, i) => (
            <li key={i} className="bg-white p-3 rounded shadow">
              <p>{msg.message}</p>
              <small className="text-gray-500 italic">{msg.direction} via {msg.device_code}</small>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-500">Belum ada pesan.</p>
      )}
    </div>
  );
};