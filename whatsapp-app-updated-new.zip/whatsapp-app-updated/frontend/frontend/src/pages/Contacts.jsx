import { useEffect, useState } from 'react'
import axios from 'axios'

export default function Contacts() {
  const [contacts, setContacts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchContacts = async () => {
      try {
        const response = await axios.get('http://37.44.244.95:3002/api/contacts')
        setContacts(response.data)
      } catch (error) {
        console.error('Error fetching contacts:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchContacts()
  }, [])

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Daftar Kontak</h1>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left">Nama</th>
                <th className="px-6 py-3 text-left">Nomor</th>
                <th className="px-6 py-3 text-left">Device</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {contacts.map((contact) => (
                <tr key={contact.id}>
                  <td className="px-6 py-4">{contact.name}</td>
                  <td className="px-6 py-4">{contact.phone_number}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-gray-200 rounded-full text-xs">
                      {contact.device_code}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
