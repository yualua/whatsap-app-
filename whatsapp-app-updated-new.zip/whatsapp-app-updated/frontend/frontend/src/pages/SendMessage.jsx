import { useState } from 'react'
import axios from 'axios'

export default function SendMessage() {
  const [form, setForm] = useState({
    device: 'd1',
    phone: '',
    message: ''
  })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      await axios.post('http://37.44.244.95:3002/api/whatsapp/send', form)
      setSuccess(true)
      setForm({ ...form, message: '' })
      setTimeout(() => setSuccess(false), 3000)
    } catch (error) {
      console.error('Error sending message:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Kirim Pesan</h1>
      <form onSubmit={handleSubmit} className="max-w-lg space-y-4">
        <div>
          <label className="block mb-1">Device</label>
          <select 
            value={form.device}
            onChange={(e) => setForm({ ...form, device: e.target.value })}
            className="w-full p-2 border rounded"
            required
          >
            <option value="d1">Device 1</option>
            <option value="d2">Device 2</option>
          </select>
        </div>
        
        <div>
          <label className="block mb-1">Nomor Tujuan</label>
          <input
            type="text"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="w-full p-2 border rounded"
            placeholder="628xxxxxx"
            required
          />
        </div>
        
        <div>
          <label className="block mb-1">Pesan</label>
          <textarea
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            className="w-full p-2 border rounded h-32"
            required
          />
        </div>
        
        <button
          type="submit"
          disabled={loading}
          className={`px-4 py-2 rounded text-white ${loading ? 'bg-gray-400' : 'bg-primary hover:bg-primary-dark'}`}
        >
          {loading ? 'Mengirim...' : 'Kirim Pesan'}
        </button>
        
        {success && (
          <div className="p-2 bg-green-100 text-green-800 rounded">
            Pesan berhasil dikirim!
          </div>
        )}
      </form>
    </div>
  )
}
