import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import SendMessage from './pages/SendMessage';
import ChatHistory from './pages/ChatHistory';
import Contacts from './pages/Contacts';
import Layout from './components/Layout';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/send" element={<SendMessage />} />
          <Route path="/history" element={<ChatHistory />} />
          <Route path="/contacts" element={<Contacts />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App
