/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          light: '#25D366',
          DEFAULT: '#128C7E',
          dark: '#075E54',
        },
        secondary: {
          light: '#34B7F1',
          DEFAULT: '#25D366',
        }
      },
    },
  },
  plugins: [],
}
