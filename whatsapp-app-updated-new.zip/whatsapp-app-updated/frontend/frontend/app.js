const ws = new WebSocket("ws://37.44.244.95:3003");

ws.onmessage = e => {const data = JSON.parse(e.data);

const li = document.createElement("li");li.textContent = `${data.sender}: ${data.message}`;document.getElementById("messages").appendChild(li);};
