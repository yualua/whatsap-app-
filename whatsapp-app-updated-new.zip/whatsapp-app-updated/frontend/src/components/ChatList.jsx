
import React from 'react';

const ChatList = ({ conversations, activeChat, onSelect }) => {
  return (
    <div className="w-1/3 border-r overflow-y-auto">
      {conversations.map(conv => (
        <div
          key={conv.number}
          onClick={() => onSelect(conv)}
          className={`p-4 cursor-pointer hover:bg-gray-100 ${
            activeChat?.number === conv.number ? 'bg-gray-200' : ''
          }`}
        >
          <div className="font-semibold">{conv.name || conv.number}</div>
          <div className="text-sm text-gray-500 truncate">{conv.lastMessage}</div>
        </div>
      ))}
    </div>
  );
};

export default ChatList;
