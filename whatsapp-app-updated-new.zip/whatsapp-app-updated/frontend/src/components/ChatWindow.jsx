
import React, { useEffect, useState, useRef } from 'react';
import MessageInput from './MessageInput';

const ChatWindow = ({ chat }) => {
  const [messages, setMessages] = useState([]);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (!chat) return;
    fetch(`/api/messages/${chat.number}`)
      .then(res => res.json())
      .then(data => setMessages(data));
  }, [chat]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!chat) return <div className="flex-1 flex items-center justify-center text-gray-500">Pilih chat</div>;

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-gray-50">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`max-w-xs px-4 py-2 rounded-lg ${
              msg.from === 'me' ? 'bg-blue-500 text-white self-end' : 'bg-white text-gray-800 self-start border'
            }`}
          >
            {msg.text}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <MessageInput chat={chat} onSend={msg => setMessages([...messages, msg])} />
    </div>
  );
};

export default ChatWindow;
