
import React, { useState, useEffect } from 'react';
import ChatList from './components/ChatList';
import ChatWindow from './components/ChatWindow';

const ChatApp = () => {
  const [conversations, setConversations] = useState([]);
  const [activeChat, setActiveChat] = useState(null);

  useEffect(() => {
    // Fetch daftar percakapan dari server
    fetch('/api/conversations')
      .then(res => res.json())
      .then(data => setConversations(data));
  }, []);

  return (
    <div className="flex h-screen">
      <ChatList
        conversations={conversations}
        activeChat={activeChat}
        onSelect={setActiveChat}
      />
      <ChatWindow chat={activeChat} />
    </div>
  );
};

export default ChatApp;
