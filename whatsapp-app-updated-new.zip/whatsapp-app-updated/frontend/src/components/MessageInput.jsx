
import React, { useState } from 'react';

const MessageInput = ({ chat, onSend }) => {
  const [text, setText] = useState('');

  const handleSend = () => {
    if (!text.trim()) return;
    const newMessage = { from: 'me', text };
    fetch('/api/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: chat.number, message: text }),
    });
    onSend(newMessage);
    setText('');
  };

  return (
    <div className="p-4 border-t flex gap-2 bg-white">
      <input
        type="text"
        value={text}
        onChange={e => setText(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && handleSend()}
        className="flex-1 border rounded px-4 py-2"
        placeholder="Ketik pesan..."
      />
      <button onClick={handleSend} className="bg-blue-500 text-white px-4 py-2 rounded">
        Kirim
      </button>
    </div>
  );
};

export default MessageInput;
