
import React from 'react';
import ChatApp from './components/ChatApp';

const App = () => {
  return <ChatApp />;
};

export default App;
