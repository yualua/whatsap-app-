module.exports = {
  apps: [
    {
      name: 'whatsapp-backend',
      script: 'server.js',
      cwd: '/root/whatsapp-app/backend',
      env: {
        DB_HOST: 'localhost',
        DB_USER: 'root',
        DB_PASS: 'defray',
        DB_NAME: 'whatsapp_db',
        PORT: 3002,
        DEVICE_1_TOKEN: 'Gausr8meZeKAvS48WDdn',
        DEVICE_2_TOKEN: 'yas9UrMV2iQVRxb1i8wr',
        ACCOUNT_TOKEN: 'FFYsV4d2yT5ASExi5BWy3m6bvz5uAT1J6XXt3FcKktNiAUSdKR',
        FONNTE_BASE_URL: 'https://api.fonnte.com',
        JWT_SECRET: 'your_jwt_secret_here'
      }
    }
  ]
};
