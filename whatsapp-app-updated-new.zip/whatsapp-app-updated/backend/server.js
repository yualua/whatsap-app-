import express from 'express'; 
import cors from 'cors'; 
import dotenv from 'dotenv'; 
import routes from './routes/whatsappRoutes.js'; 
import wss from './websocket.js'; 
import { saveIncomingMessage } from './services/fonnteService.js';


dotenv.config(); 
const app = express(); 
app.use(cors({
  origin: '*'
}));
app.use(express.json()); 
app.use('/api/whatsapp', routes);
import chatRoutes from './routes/chatRoutes.js';
app.use('/api/chat', chatRoutes); // artinya /api/whatsapp/webhook

app.get('/', (req, res) => res.send('API active')); 

// Webhook root endpoint
app.post('/webhook', async (req, res) => {
  try {
    const { sender, device, message } = req.body;
    if (!sender || !device || !message) return res.status(400).send('Missing required fields');
    
    console.log('[Webhook] Menerima pesan dari', sender);
    await saveIncomingMessage(device, sender, message);
    console.log('[Webhook] Sukses simpan ke database');
    console.log('Webhook saved via root / route:', req.body);
    res.status(200).send('Webhook received via root');
  } catch (e) {
    console.error('Root webhook failed:', e);
    res.status(500).send('Root webhook error');
  }
});

const PORT = process.env.PORT || 3002; 
app.listen(PORT, '0.0.0.0', () => console.log(`✅  Server running on port ${PORT}`));