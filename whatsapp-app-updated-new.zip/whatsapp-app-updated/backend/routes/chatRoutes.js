
import express from 'express';
import fs from 'fs';
import path from 'path';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();
const router = express.Router();

const inboxPath = path.resolve('inbox.json');
const sentPath = path.resolve('sentMessages.json');

router.get('/conversations', (req, res) => {
  if (!fs.existsSync(inboxPath)) return res.json([]);
  const raw = JSON.parse(fs.readFileSync(inboxPath));
  const grouped = {};

  raw.forEach(msg => {
    if (!grouped[msg.sender]) {
      grouped[msg.sender] = {
        number: msg.sender,
        name: msg.name || msg.sender,
        lastMessage: msg.message,
        timestamp: msg.timestamp,
      };
    } else if (new Date(msg.timestamp) > new Date(grouped[msg.sender].timestamp)) {
      grouped[msg.sender].lastMessage = msg.message;
      grouped[msg.sender].timestamp = msg.timestamp;
    }
  });

  const result = Object.values(grouped).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  res.json(result);
});

router.get('/messages/:number', (req, res) => {
  const number = req.params.number;
  if (!fs.existsSync(inboxPath)) return res.json([]);
  const raw = JSON.parse(fs.readFileSync(inboxPath));
  const filtered = raw
    .filter(msg => msg.sender === number)
    .map(msg => ({
      from: 'user',
      text: msg.message,
      timestamp: msg.timestamp,
    }));
  if (fs.existsSync(sentPath)) {
    const sent = JSON.parse(fs.readFileSync(sentPath)).filter(m => m.target === number);
    sent.forEach(m => {
      filtered.push({ from: 'me', text: m.message, timestamp: m.timestamp });
    });
  }
  res.json(filtered.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp)));
});

router.post('/send', async (req, res) => {
  const { to, message } = req.body;
  if (!to || !message) return res.status(400).send('Missing "to" or "message"');

  const newMsg = { target: to, message, timestamp: new Date().toISOString() };

  const sent = fs.existsSync(sentPath) ? JSON.parse(fs.readFileSync(sentPath)) : [];
  sent.push(newMsg);
  fs.writeFileSync(sentPath, JSON.stringify(sent, null, 2));

  try {
    const result = await axios.post('https://api.fonnte.com/send', {
      target: to,
      message: message,
    }, {
      headers: {
        'Authorization': process.env.FONNTE_TOKEN
      }
    });

    console.log('[SEND] Success:', result.data);
    res.json({ success: true, result: result.data });
  } catch (err) {
    console.error('[SEND] Failed to send message:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
