import express from 'express';
//import pool from '../config/db.js';
import { saveIncomingMessage } from '../services/fonnteService.js';
import db from '../db.js'; // pastikan path sesuai dengan lokasi file db.js
const router = express.Router();

// GET: fetch 50 pesan terbaru
router.get('/messages/recent', async (req, res) => {
  try {
    const [rows] = await db.query(`
  SELECT
    m.*, 
    c.name AS contact_name, 
    c.phone_number 
  FROM messages m
  JOIN contacts c ON m.contact_id = c.id
  ORDER BY m.id DESC
  LIMIT 20
`);
    console.log('✅ Fetched messages:', rows);
    res.json(rows);
  } catch (err) {
    console.error('❌ Error fetching recent messages:', err);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

// POST: simpan pesan masuk dari webhook
// POST: simpan pesan masuk dari webhook
router.post('/webhook', async (req, res) => {
  try {
    const { sender, device, message, name } = req.body;
    if (!sender || !device || !message) {
      return res.status(400).send('Missing required fields');
    }

    await saveIncomingMessage(device, sender, message, name);
    console.log('✅ Webhook saved:', req.body);
    res.status(200).send('Webhook saved');
  } catch (error) {
    console.error('❌ Webhook processing failed:', error);
    res.status(500).send('Webhook failed');
  }
});

// GET: test webhook endpoint
router.get('/webhook', (req, res) => {
  res.status(200).send('Webhook endpoint active (GET)');
});

// GET: riwayat pesan per kontak
router.get('/messages/history/:contactId', async (req, res) => {
  try {
    const contactId = req.params.contactId;
    const [messages] = await db.query('SELECT message, device_code, direction FROM messages WHERE contact_id = ? ORDER BY id DESC',
      [contactId]);
    res.json(messages);
  } catch (error) {
    console.error('❌ Get message history error:', error);
    res.status(500).send('Failed to get message history');
  }
});

export default router;