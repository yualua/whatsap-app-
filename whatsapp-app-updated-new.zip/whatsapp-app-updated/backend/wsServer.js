import { WebSocketServer } from 'ws';
const wss = new WebSocketServer({ port: 3003 });
console.log('🟢 WebSocket Server running on port 3003');

function broadcast(message) {
  wss.clients.forEach(client => {
    if (client.readyState === 1) {
      client.send(JSON.stringify(message));
    }
  });
}

export { broadcast };
