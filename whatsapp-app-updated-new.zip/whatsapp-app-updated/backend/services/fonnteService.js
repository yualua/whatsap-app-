import wss from '../websocket.js';
import axios from 'axios';
import db from '../db.js';

// Fungsi untuk mengirim pesan (outgoing)
export async function sendMessage(device, phone, message) {
  try {
    const token = device === 'd1' 
      ? process.env.DEVICE_1_TOKEN 
      : process.env.DEVICE_2_TOKEN;

    const response = await axios.post(`${process.env.FONNTE_BASE_URL}/send`, {
      target: phone,
      message,
      delay: '1-5'
    }, {
      headers: { 'Authorization': token }
    });

    // Simpan ke database sebagai pesan keluar
    await db.query(
      'INSERT INTO messages (contact_id, device_code, message, direction) VALUES (?, ?, ?, ?)',
      [1, device, message, 'outgoing']
    );

    return response.data;
  } catch (error) {
    console.error('SendMessage Error:', error);
    throw error;
  }
}

// Fungsi untuk menyimpan pesan masuk dan kontak pengirim
export async function saveIncomingMessage(device, sender, message, name = null) {
  try {
    // Cek atau buat kontak jika belum ada
    const [existing] = await db.query('SELECT id FROM contacts WHERE phone_number = ?', [sender]);
    let contactId;

    if (existing.length > 0) {
      contactId = existing[0].id;
    } else {
      const [result] = await db.query(
        'INSERT INTO contacts (phone_number, name) VALUES (?, ?)',
        [sender, name || 'Unknown']
      );
      contactId = result.insertId;
    }

    // Simpan pesan masuk
    await db.query(
      'INSERT INTO messages (contact_id, device_code, message, direction) VALUES (?, ?, ?, ?)',
      [contactId, device, message, 'incoming']
    );
  } catch (err) {
    console.error('❌ Gagal simpan pesan masuk:', err);
  }
}